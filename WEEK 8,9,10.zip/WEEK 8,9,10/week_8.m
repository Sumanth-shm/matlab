%% MATLAB Code for Numerical Fourier Transform (Method 1)

% Define the continuous-time energy signal and its parameters
T1 = 0;             % Start time of the non-zero duration
T2 = pi;            % End time of the non-zero duration

% 1. Define the time range wide enough to cover the entire non-zero duration [cite: 7]
h = 0.001;          % 2. Appropriate step size 'h' 
t = T1:h:T2;        % Time vector

% 3. Define the continuous-time energy signal x(t) 
x_t = exp(-t./2);   % Signal: x(t) = exp(-t/2) for 0 <= t <= pi

% Define the frequency range for the spectrum
w_start = -20;      % Starting angular frequency
w_end = 20;         % Ending angular frequency
w_step = 0.1;       % Frequency step size
w = w_start:w_step:w_end; % Angular frequency vector

% Initialize the array for the computed spectral components
Xr = zeros(1, length(w)); % Initialize the array for the spectrum X(j*omega)
rk = 0;                   % 4. Initialize index counter 'rk' to zero 

% 5. Use a loop to compute the Fourier spectral components 
for rk = 1:length(w)
    % Compute the FT component X(j*omega) using the summation approximation
    % X(j*omega) = sum(x(t) .* exp(-j*omega*t)) * h;
    
    % NOTE: In MATLAB, 'j' is a built-in imaginary unit. We use 'w(rk)' for the 
    % specific frequency in the loop. The '.*' is for element-wise multiplication.
    Xr(rk) = sum(x_t .* exp(-1i .* w(rk) .* t)) .* h; 
end

%% 6. Plot the magnitude and phase of the computed spectral response [cite: 13]

figure;

% --- Plot Magnitude Spectrum ---
subplot(2, 1, 1);
plot(w, abs(Xr), 'b', 'LineWidth', 1.5);
title('Magnitude Spectrum |X(j\omega)|');
xlabel('\omega (rad/s)');
ylabel('Magnitude');
grid on;

% --- Plot Phase Spectrum ---
subplot(2, 1, 2);
plot(w, angle(Xr), 'r', 'LineWidth', 1.5);
title('Phase Spectrum \angle X(j\omega)');
xlabel('\omega (rad/s)');
ylabel('Phase (radians)');
grid on;



%% MATLAB Code for Zero-State Response (FT Approach)

% --- PART 1: Define Parameters and Signal (Same as previous FT code) ---

T1 = 0;             % Start time of the non-zero duration
T2 = pi;            % End time of the non-zero duration
h = 0.001;          % Time step size for the signal
t_signal = T1:h:T2; % Time vector for the signal x(t)
x_t = exp(-t_signal./2); % The input signal x(t) = exp(-t/2) for 0 <= t <= pi

% Define the frequency range for the spectrum
w_start = -100;     % Wider frequency range needed for IFT convergence
w_end = 100;
w_step = 0.05;      % Finer frequency step size for better accuracy
w = w_start:w_step:w_end; % Angular frequency vector
dw = w_step;        % Frequency step size (dw)

% --- PART 2: Compute X(j*omega) and H(j*omega) ---

% Compute Input Signal Spectrum X(j*omega)
Xr = zeros(1, length(w));
for rk = 1:length(w)
    % X(j*omega) = sum(x(t) .* exp(-j*omega*t)) * h;
    Xr(rk) = sum(x_t .* exp(-1i .* w(rk) .* t_signal)) .* h;
end

% Compute System Transfer Function H(j*omega)
% H(D) = 1/(D+2)  =>  H(j*omega) = 1/(j*omega + 2)
Hw = 1 ./ (1i .* w + 2);

% Compute Output Spectrum Y(j*omega)
Yw = Xr .* Hw;

% --- PART 3: Compute the Inverse Fourier Transform (IFT) of Y(j*omega) ---

% Define the time range for the output signal y(t)
t_start = 0;
t_end = 10;         % Define a long enough time for the response to decay
dt = 0.05;          % Time resolution for the output
t_output = t_start:dt:t_end; % Output time vector

% Initialize the array for the computed output signal y(t)
y_t = zeros(1, length(t_output));

% The IFT formula is: x(t) = (1/(2*pi)) * Integral(X(j*omega) * exp(j*omega*t) d*omega)
% Numerical approximation (Summation): y(t) = (1/(2*pi)) * sum(Y(j*omega) * exp(j*omega*t)) * dw
for k = 1:length(t_output)
    % Compute the IFT component y(t) using the summation approximation
    y_t(k) = (1/(2*pi)) * sum(Yw .* exp(1i .* w .* t_output(k))) .* dw;
end

% Since y(t) is a real signal, take the real part to eliminate numerical noise
y_t = real(y_t);

%% --- PART 4: Plot the Output Signal y(t) ---

figure;
plot(t_output, y_t, 'g', 'LineWidth', 2);
title('Zero-State Response y(t) of the System');
xlabel('Time t (s)');
ylabel('Output Signal y(t)');
grid on;