f = inline('exp(-n/10).*cos(n*pi/5).*(n>=0)','n')
n=[-10:20];
% stem(n, f(n), 'k')
energy1 = sum((f(n).*f(n)));
xe=0.5*(f(n)+f(-n));
xo=0.5*(f(n)-f(-n));
% stem(n, xe, 'k')
% stem(n, xo, 'k')


%  q.   y[n+2] – y[n+1] + 0.24y[n] = x[n+2] – 2x[n+1] 


% --- Impulse Response h[n] (Using filter) ---
N = 2; % System order 
b = [1 -2 0]; 
a =  [1 -1 0.24];
n = [0:30]'; % Time range for output 

% Define a discrete-time impulse delta[n] = 1 at n=0, 0 otherwise
delta = zeros(length(n), 1);
delta(1) = 1; % delta[0] = 1

% Calculate Impulse Response h[n]
h = filter(b, a, delta); 

figure;
stem(n, h, 'k');
title('Impulse Response h[n]');
xlabel('Discrete Time n');
ylabel('h[n]');
grid on;


% --- Zero-State Response ys[n] (Using filter) ---
b = [1 -2 0];
a =  [1 -1 0.24];
n = [0:30]'; 

% Define the unit step function u[n] = 1 for n>=0
x_step = ones(length(n), 1); 

% Calculate Zero-State Response ys[n]
ys = filter(b, a, x_step);

figure;
stem(n, ys, 'k');
title('Zero-State Response ys[n] for x[n]=u[n]');
xlabel('Discrete Time n');
ylabel('ys[n]');
grid on;



% --- MATLAB Code for Total Response (Iterative Method 1) ---

% Define the discrete time range for the solution, including initial conditions 
n = [-2:10]'; 
len_n = length(n);

% Predefine output array 'y' with initial conditions 
y = zeros(len_n, 1);
y(1) = 1; % y[-2] = 1 (at array index 1)
y(2) = 2; % y[-1] = 2 (at array index 2)

% Define the input array 'x'
% x[n] = n*u[n]. x[-2]=0, x[-1]=0, x[n>=0]=n. 
% n(3:end) starts from n=0 up to the end of the time range
x = [0; 0; n(3:end)]; 

% Iterative computation starts here (for k=1, y(3) is computed, which is y[0]) 
for k = 1:len_n - 2 
    % y(k+2) = y(k+1) - 0.24*y(k) + x(k+2) - 2*x(k+1) 
    % (Note: Indices k+2, k+1, k correspond to time n, n-1, n-2 in the original difference equation)
    y(k+2) = y(k+1) - 0.24*y(k) + x(k+2) - 2*x(k+1);
end

% Resulting Total Response array
disp('Total Response y[n] array:');
disp(y'); 

% Sketch of the solution including the initial conditions [cite: 91, 92]
figure;
stem(n, y, 'k');
title('Total Response y[n] (Iterative Procedure)');
xlabel('Discrete Time n');
ylabel('y[n]');
grid on;




% --- Filter Method for ZSR (I.C.s=0) ---

% Define time range starting at n=0 for filter output
n_filter = [0:30]'; 

% Define system coefficients in delay form: a_k*y[n-k] = b_k*x[n-k]
% y[n] - y[n-1] + 0.24y[n-2] = x[n] - 2x[n-1] + 0x[n-2]
b = [1 -2 0];       
a = [1 -1 0.24];   

% Define the input signal x[n] = n*u[n] for n>=0 [cite: 121]
x_zs = n_filter; 

% Calculate the Zero-State Response (ZSR)
y_zs = filter(b, a, x_zs); 

% Plotting result
figure;
stem(n_filter, y_zs, 'k');
title('Zero-State Response y_{zs}[n] (Filter Command)');
xlabel('Discrete Time n');
ylabel('y_{zs}[n]');
grid on;


%% WEEK 10: DTFS COEFFICIENTS - METHOD 1 (Direct Computation)

No = 32;                   % Period [cite: 9]
n = 0:No-1;                % Time index for one period [cite: 9]
xn = [ones(1, 5) zeros(1, 23) ones(1, 4)]; % Signal x[n] for 0 <= n <= 31 [cite: 10]
r = 0:No-1;                % Index for coefficients Dr [cite: 13]

xr = zeros(1, No);         % Initialize coefficient array
j = sqrt(-1);

for r_idx = r
    % Dr = (1/No) * sum( x[n] * exp(-j*r*Omega_0*n) ) [cite: 11]
    xr(r_idx + 1) = sum(xn .* exp(-j * r_idx * 2 * (pi/No) * n)) / No;
end

% Plotting Magnitude and Phase Spectra [cite: 14]
xr = round(1000 * xr) / 1000; % to omit computational error in angle [cite: 14]

figure;
subplot(2, 1, 1);
stem(r, abs(xr), 'k');
ylabel('|Dr|'); 
xlabel('r');
title('DTFS Coefficients |Dr| (Direct Computation)');
grid on;
% ... plot for angle(xr) omitted for brevity ...

%% WEEK 10: DTFS COEFFICIENTS - METHOD 2 (Using FFT)

No = 32;
xn = [ones(1, 5) zeros(1, 23) ones(1, 4)];
r = 0:No-1;

xr1 = fft(xn) / No; % Normalized FFT gives the DTFS coefficients Dr [cite: 16]

% Plotting Magnitude and Phase Spectra [cite: 17]
figure;
subplot(2, 1, 1);
stem(r, abs(xr1), 'k');
ylabel('|Dr|'); 
xlabel('r');
title('DTFS Coefficients |Dr| (using FFT)');
grid on;
% ... plot for angle(xr1) omitted for brevity ...


%% WEEK 10: DTFS RECONSTRUCTION (Inverse DTFS)

No = 32;
n = 0:No-1;
r = 0:No-1;
xr = xr1; % Use coefficients computed by FFT/Direct Method

x_reconstructed = zeros(1, No);
j = sqrt(-1);

for n_idx = n
    sum_term = 0;
    for r_idx = r
        % Synthesis Equation: x[n] = sum( Dr * exp(j * r * Omega_0 * n) )
        sum_term = sum_term + xr(r_idx + 1) * exp(j * r_idx * 2 * (pi/No) * n_idx);
    end
    x_reconstructed(n_idx + 1) = sum_term;
end

% Take the real part to eliminate small imaginary components due to numerical error
x_reconstructed = real(x_reconstructed);

% Plotting the reconstructed signal
figure;
stem(n, x_reconstructed, 'b');
hold on;
stem(n, [ones(1, 5) zeros(1, 23) ones(1, 4)], 'ro');
title('DTFS Reconstruction of x[n]');
xlabel('n');
ylabel('x[n]');
legend('Reconstructed', 'Original');
grid on;


%% WEEK 10: DTFT COMPUTATION (Method 1: First Principle)

% Signal: x[n] = (0.7071)^n for 0 <= n <= 4
a = 0.7071;

% 1. Define the time range (non-zero duration) [cite: 55]
n = [0:4]; 
x_n = a.^n;

% 2. Define the continuous frequency range Omega and step size 'h' [cite: 58, 59]
h = 0.01;
Omega = -pi:h:pi; % Omega from -pi to pi

% 3. Compute the DTFT X(e^jOmega)
j = sqrt(-1);
X_Omega = zeros(1, length(Omega));

for rk = 1:length(Omega) % Loop through frequency steps
    current_Omega = Omega(rk);
    
    % X(e^jOmega) = sum( x[n] * exp(-j*Omega*n) ) [cite: 60]
    X_Omega(rk) = sum(x_n .* exp(-j * current_Omega * n));
end

% 4. Sketch Magnitude and Phase Spectra [cite: 61]
figure;
subplot(2, 1, 1);
plot(Omega, abs(X_Omega), 'b');
title('DTFT Magnitude Spectrum |X(e^{j\Omega})| (First Principle)');
xlabel('\Omega (Radians)');
ylabel('|X(\Omega)|');
grid on;

subplot(2, 1, 2);
plot(Omega, angle(X_Omega), 'b');
title('DTFT Phase Spectrum \angle X(e^{j\Omega})');
xlabel('\Omega (Radians)');
ylabel('\angle X(\Omega)');
grid on;

