function ydot=fn3(t,y);
ydot=zeros(2,1);
ydot(1)=y(2);
ydot(2)=-1*y(2)-13*y(1)+8+ (exp(-0.5*t) * (-2*sin(3.5707*t) + 14.2828*cos(3.5707*t)));
end