function ydot=fn2(t,y);
ydot=zeros(2,1);
ydot(1)=y(2);
ydot(2)=-9*y(1)+2;
end