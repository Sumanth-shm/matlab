h = @(t) ((12/sqrt(51))*exp(-t/2).*cos((sqrt(51)*t/2) + pi/2) + ...
          4*exp(-0.5).*sin((sqrt(51)*t/2) + pi/2)) .* (t >= 0);

x = @(t) (exp(-0.5*t) .* sin(3.5707*t)) .* (t >= 0);

tvec = -0.25:.01:5; 
dtau = 0.05;    
tau= -3.5:dtau:5;   
ti= 0;      
y=NaN*zeros(1,length(tvec));    
for t = tvec,   
ti=ti+1;    
xh= x(tau).* h(t-tau);    
y(ti) = sum(xh.*dtau);
subplot(2,1,1), plot(tau,x(tau),'r_',tau,h(t-tau),'m-',t,0,'ro'); 
subplot(2,1,2), plot(tvec,y,'b',tvec(ti),y(ti),'ro'); 
drawnow;  % pause; 
end  
figure; plot(tvec,y)   

