x=inline('1*(t>=0)','t') 
h=inline('(3*(cos(3*t))+((2*sin(3*t))/3)).*(t>=0)','t') 
tvec = -0.25:.01:5; 
dtau = 0.05;    
tau= -3.5:dtau:5;   
ti= 0;      
y=NaN*zeros(1,length(tvec));    
for t = tvec,   
ti=ti+1;    
xh= x(tau).* h(t-tau);    
y(ti) = sum(xh.*dtau);
subplot(2,1,1), plot(tau,x(tau),'r_',tau,h(t-tau),'m-',t,0,'ro'); 
subplot(2,1,2), plot(tvec,y,'b',tvec(ti),y(ti),'ro'); 
drawnow;  % pause; 
end  
figure; plot(tvec,y)   
