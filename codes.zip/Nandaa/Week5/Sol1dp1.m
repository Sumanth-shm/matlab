y0=[0;0]; 
t=[0:0.01:10]; 
[t,y]=ode23(@fn4,t,y0);

figure;
plot(t,y(:,1),'r','LineWidth',1.5); hold on;
plot(t,y(:,2),'b','LineWidth',1.5);
grid on;

drawnow;
xlabel('time');
ylabel('system response');
legend('y(t)','dy(t)/dt')
title('plot for ZIR of D(D+1)y(t)=0');