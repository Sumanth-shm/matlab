function ydot=fn1(t,y);
ydot=zeros(2,1);
ydot(1)=y(2);
ydot(2)=-y(2)+2;
end