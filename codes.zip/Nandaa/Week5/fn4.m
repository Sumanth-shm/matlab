function ydot=fn4(t,y);
ydot=zeros(2,1);
ydot(1)=y(2);
ydot(2)=-1.5*y(2)-0.5625*y(1)+8+(-3*(exp(-0.75*t)));
end