clc; clear; clf; 
To = pi;   wo = 2*pi/To;          
h =  0.001;  t = 0:h:(To-h);       
yyy = inline('exp(-(t+pi)/2).*((t>=-pi)&(t<0))+exp(-t/2),*((t>=0)&(t<pi))+exp(-t-pi)/2).*((t>=pi)&(t<2*pi)) ','t');
y=yyy(t-0.5);
plot(t,y)

