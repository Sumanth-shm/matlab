f= @(x) 1./((x.^2)-1) ;

figure;
plot(t,f(t))