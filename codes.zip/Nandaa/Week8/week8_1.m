clc; clear; clf; 
To = pi;            
h =  0.01;  
t = 0:h:(To-h);       
y = exp(-t/2);    
k=0;
for n = -10:h:10 
    k=k+1;
d(k) = sum(y.*exp(-j*n*t))*h;    
end               
n = -10:h:10;     
subplot(2,1,1); plot(n,abs(d),'k'); ylabel('magnitude'); xlabel('n'); 
subplot(2,1,2); plot(n,angle(d),'k'); ylabel('angle'); xlabel('n'); 

%Recnstruction
tk=0;
for t = -To:h:(To-h)
    tk=tk+1;
yy(tk) = (1/(2*pi))*sum(d.*exp(j*n*t)*h);    
end  
t = -To:h:(To-h);
figure;
plot(t,yy)
%Reversal can be done by removing/adding the negetive sign of the j