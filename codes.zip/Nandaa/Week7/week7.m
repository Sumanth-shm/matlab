clc; clear; clf; 
To = pi; 
wo = 2*pi/To;          
h =  0.001;  t = 0:h:(To-h);       
y = exp(-t/10);  N = length(y);    
Co = sum(y)/(N-1);        
for n = 1:10   
wo = 2*pi/To;        
t = 0:h:(To-h); 
N = length(y);             
% Number of Fourier terms 
a(n) = 2*sum(y.*cos(n*wo*t))/(N-1);   
b(n) = 2*sum(y.*sin(n*wo*t))/(N-1); 
end 
Cn     = sqrt(a.^2+b.^2);                
n = 0:10;     
thetan = atan(-b./a); 
subplot(2,2,1); stem(n,[Co a],'k'); ylabel('an'); xlabel('n'); 
subplot(2,2,2); stem(n,[0 a],'k'); ylabel('bn'); xlabel('n'); 
subplot(2,2,3); stem(n,[Co Cn],'k'); ylabel('cn'); xlabel('n'); 
subplot(2,2,4); stem(n,[0 thetan],'k'); ylabel('\theta[rad]'); xlabel('n'); 