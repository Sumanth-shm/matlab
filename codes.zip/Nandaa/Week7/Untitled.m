clc; clear; clf; 
To = pi;   wo = 2*pi/To;          
h =  0.001;  t = 0:h:(To-h);       
%y = exp(-t/2);  N = length(y);    
Co = sum(y)/(N-1);
yyy = inline('exp(-(t+pi)/2).*((t>=-pi)&(t<0))+exp(-t/2).*((t>=0)&(t<pi))+exp(-(t-pi)/2).*((t>=pi)&(t<2*pi)) ','t');
y=yyy(t-0.5); %here depending on question you put,if they say reversal then x(-t)


%Analysis
k=0;
for n = -10:10 
    k=k+1
d(k) = sum(y.*exp(-j*n*wo*t))/(N-1);    
end               
n = -10:10;     
subplot(2,1,1); stem(n,abs(d),'k'); ylabel('magnitude'); xlabel('n'); 
subplot(2,1,2); stem(n,angle(d),'k'); ylabel('angle'); xlabel('n'); 

%Recnstruction
tk=0;
for t = -To:h:(To-h);
    tk=tk+1;
yy(tk) = sum(d.*exp(j*n*wo*t));    
end  
t = -To:h:(To-h);
figure;
plot(t,yy)
%Reversal can be done by removing/adding the negetive sign of the j