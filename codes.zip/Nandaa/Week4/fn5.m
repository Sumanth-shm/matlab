function ydot=fn5(t,y);
ydot=zeros(2,1);
ydot(1)=y(2);
ydot(2)=y(3);
ydot(3)=-y(3);
end