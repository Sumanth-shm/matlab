function hdot=nh1(t,h);
hdot=zeros(2,1);
hdot(1)=h(2);
hdot(2)=-h(2);
end