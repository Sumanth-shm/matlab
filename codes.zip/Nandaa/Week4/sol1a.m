y0=[2;-3];                         % initial condition vector 
t=[0:0.01:10];                     %time duration for the solution 

[t,y]=ode23(@fn1,t,y0);


plot(t,y(:,1),'r','LineWidth',1.5); hold on;
plot(t,y(:,2),'b','LineWidth',1.5);
grid on;
xlabel('time');
ylabel('system response');
legend('y(t)','dy(t)/dt')
title('Function: D(D+1)y(t)=0');

%NOTE: FOR IMPULSE SOLUTION CALCULATE 2 NEW INITIALL CONDITIONS 