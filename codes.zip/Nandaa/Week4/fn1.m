function ydot=fn1(t,y);
ydot=zeros(2,1);
ydot(1)=y(2);
ydot(2)= ̶ 4*y(2) ̶ 3*y(1);
end

% (D^2+4D+3) y(t) = (3D+5) x(t)