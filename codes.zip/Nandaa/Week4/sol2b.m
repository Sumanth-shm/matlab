h0=[3;2]; 
t=[0:0.01:10]; 

[t,h]=ode23(@nh2,t,h0);

plot(t,h(:,1),'r','LineWidth',1.5); hold on;
plot(t,h(:,2),'b','LineWidth',1.5);
grid on;
xlabel('time');
ylabel('system response');
legend('h(t)','dh(t)/dt')
title('Funtion (D^2+9)y(t))=0');
