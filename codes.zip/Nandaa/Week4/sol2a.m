h0=[1;1];  
t=[0:0.01:10]; 

[t,h]=ode23(@nh1,t,h0);

plot(t,h(:,1),'r','LineWidth',1.5); hold on;
plot(t,h(:,2),'b','LineWidth',1.5);
grid on;
xlabel('time');
ylabel('system response');
legend('h(t)','dh(t)/dt')
title('Function: D(D+1)y(t)=0');