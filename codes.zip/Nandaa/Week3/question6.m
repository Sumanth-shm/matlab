y = inline ( '((1).*((t>=-1)&(t<0))) + (((1-t)).*((t>=0)&(t<1)))', 't');
t= [-2,0.01,2]
x=@(t) -2*y(2/3-t/3);

plot(t,y(t))
plot(t,x(t))

xe=0.5*(x(t)+x(-t));
xo=0.5*(x(t)-x(-t));

figure;
plot(t,xe);

figure;
plot(t,xo);