clc;
x = inline('cos(t) + sin(t) + sin(t).*cos(t)','t');
t = linspace(-2*pi,2*pi,10000);

xe=0.5*(x(t)+x(-t));
xo=0.5*(x(t)-x(-t));

figure;
plot(t,x(t));

figure;
plot(t,xe);

figure;
plot(t,xo);

x = inline('1+t+(3.*t.*t)+(5.*t.*t)+(9.*t.*t.*t.*t)','t');
t = linspace(-2*pi,2*pi,10000);

xe=0.5*(x(t)+x(-t));
xo=0.5*(x(t)-x(-t));

figure;
plot(t,x(t));

figure;
plot(t,xe);

figure;
plot(t,xo);

x = inline('(1+ (t.*cos(t)))+(t.*t.*sin(t)) + (t.*t.*t.*sin(t).*cos(t))','t');
t = linspace(-2*pi,2*pi,10000);

xe=0.5*(x(t)+x(-t));
xo=0.5*(x(t)-x(-t));

figure;
plot(t,x(t));

figure;
plot(t,xe);

figure;
plot(t,xo);


x = inline('(1+ t.^3).*(cos(10.*t).^3)','t');
t = linspace(-2*pi,2*pi,10000);

xe=0.5*(x(t)+x(-t));
xo=0.5*(x(t)-x(-t));

figure;
plot(t,x(t));

figure;
plot(t,xe);

figure;
plot(t,xo);
