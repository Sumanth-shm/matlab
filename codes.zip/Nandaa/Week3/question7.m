t=[-1;0.0001;9]
u=inline('((1).*(t>=0))','t')
y=exp((1+i*2*pi).*t).*u(t)

figure;
subplot(5,1,1)
plot(t,y)

yreal=real(exp((1+i*2*pi).*t).*u(t))
subplot(5,1,2)
plot(t,yreal)

yimag=imag(exp((1+i*2*pi).*t).*u(t))
subplot(5,1,3)
plot(t,yimag,'b')

ymag=real(exp((1+i*2*pi).*t).*u(t))
subplot(5,1,4)
plot(t,ymag,'g')