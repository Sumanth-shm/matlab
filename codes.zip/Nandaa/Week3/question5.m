x = inline('-t.*((t>=-2)&(t<-1)) + (t+1).*((t>=-1)&(t<0))+ (-t./3+1).*((t>=0)&(t<3))','t');
t = linspace(-10,10,10000);

figure;
plot(t,x(t));

v=@(t) 3*x(-0.5*(t+1));
figure;
plot(t,v(t));

signal_size=max(abs(v(t)));
fprintf('the size of the signal is %.0f\n', signal_size);

ve= 0.5*(v(t)+v(-t));
figure;
plot(t,ve);
xlabel('t');
ylabel('v(t)');
title('Even component of v(t)')

a=2;
b=-3;

figure;
subplot(2,2,1);
plot(t,v(a*t+b));
title('v(at+b)')

subplot(2,2,2);
plot(t,v(a*t)+b);
title('v(at)+b')

subplot(2,2,3);
plot(t,a*v(t+b));
title('av(t+b)')

subplot(2,2,4);
plot(t,a*v(t)+b);
title('av (t)+b')