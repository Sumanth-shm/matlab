x =inline('-t.*((t>=-4)&(t<0)) + t.*((t>=0)&(t<2))','t');
t = linspace(-500,500,10000);

figure;
plot(t,x(t));

figure;
plot(t,x(-t));

figure;
subplot(3,2,1);
plot(t,x(t+60));

subplot(3,2,2)
plot(t,x(3*t));

subplot(3,2,3)
plot(t,x(t/20))

subplot(3,2,4)
plot(t,x(2*t+8))

subplot(3,2,5)
plot(t, -3*x(-0.2*t-80)+1.5)

subplot(3,2,6)
plot(t,2*x(2-t)-4)