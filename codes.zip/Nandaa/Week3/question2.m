w_values = [100*pi,500*pi,1000*pi];

for i=1:length(w_values)
    w=w_values(i);
    t=linspace(-pi/w,pi/w,10000);
    x=0.5*(cos(w*t)+1);
    figure;
    plot(t,x)
    
    dt=t(2)-t(1);
    Ex=sum((x.*x)*dt);
    fprintf('The total energy for w= %2.f*pi : %f\n', w/pi , Ex)
end

w=1000*pi;
t=linspace(-0.004,0.004,100000);
x_trans(mask_trans) = 0.5* (cos(w*t_trans(mask_trans))+1);
figure
plot(t,15*(0.5*cos(w.*(-0.5.*t-8)+1)-5));