f=@(r) (12^2.*r)./((r+2.5).^2)
r=linspace(1,10,1000)
p=f(r)
plot(r ,p);