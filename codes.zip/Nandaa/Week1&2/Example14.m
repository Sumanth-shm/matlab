f= @(x) 3.*x.*sin(x)-2.*x ;
x =linspace(-2*pi,2*pi,1000) ;
y=  f(x);
dy = gradient(y,x);
plot(x,y,'b');
hold  on;

plot(x,dy,'r--');
hold off;
