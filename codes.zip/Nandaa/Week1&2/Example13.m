f= @(x) (1.5*x)./(x-4);

x1=linspace(-10,3.7,1000);
x2=linspace(4.3,10,1000);
y1=f(x1);
y2=f(x2);


plot(x1, y1);
hold on;
plot(x2, y2);
hold off;