A= randi([0 10],5,6);
B= randi([0 10],2,45);
C = reshape([A(:); B(:)], 8, 15)