f= @(x) 0.6*x.^5 - 5*x.^3 + 9*x + 2;

x1=linspace(-4,4,1000);
x2=linspace(-2.7,2.7,1000);
y1=f(x1);
y2=f(x2);

subplot(2,1,1)
plot(x1, y1)
title('Plot 1')
subplot(2,1,2)
plot(x2, y2)
title('Plot 2')
