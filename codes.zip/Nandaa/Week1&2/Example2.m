x=pi/5
a=(cos(x/2))^2
b=(tan(x) + sin(x))/(2*tan(x))
c=cos(x/2)
d=sqrt((1+cos(x))/2)
e=tan(2*x)
f=(2*tan(x))/(1-((tan(x))^2))
