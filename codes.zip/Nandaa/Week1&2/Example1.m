x = 9.6;
z = 8.1;
a = (x * z * z) - ((2 * z) / (3 * x))^(3/5);
b = ((433*z)/(2*x*x*x)) + ((exp(-x*z))/(x+z));
c=(sqrt(14*x*x*x))/(exp(3*x));
d=log((x*x)-(x*x*x));