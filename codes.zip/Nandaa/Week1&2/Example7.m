A = randi([1 10],39,75);
plot(A(5,:),A(32,:));
a=[A(15,:);zeros(38,75)];
b=[A(:,4);zeros(39,74)];
plot(a,b);

c=[A(15,:);zeros(38,75)];
d=[A(:,6);zeros(39,74)];
plot(c,d);

e=reshape([A(1,:)';A(1:29,66)],4,26);

